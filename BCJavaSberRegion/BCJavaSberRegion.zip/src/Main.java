import java.io.File;
import java.util.*;

public class Main {

    public static List<City> listCity(File data) throws Exception {
        Scanner cityData = new Scanner(data);
        List<City> cityList = new ArrayList<City>();
        while (cityData.hasNextLine()) {
            String city = cityData.nextLine();
            String[] paramCity = city.split(";");
            if (paramCity.length == 6) {
                City modelCity = new City(paramCity[1], paramCity[2], paramCity[3], paramCity[4], paramCity[5]);
                cityList.add(modelCity);
            } else {
                City modelCity = new City(paramCity[1], paramCity[2], paramCity[3], paramCity[4]);
                cityList.add(modelCity);
            }
        }
        return cityList;
    }

    public static class City {
        String name;
        String region;
        String district;
        int population;
        String foundation;

        public City(String name, String region, String district, String population, String foundation) {
            this.name = name;
            this.region = region;
            this.district = district;
            this.population = Integer.parseInt(population);
            this.foundation = foundation;
        }

        public City(String name, String region, String district, String population) {
            this.name = name;
            this.region = region;
            this.district = district;
            this.population = Integer.parseInt(population);

        }

        public String toString() {
            return "City{" +
                    "name='" + name + '\'' +
                    ", region='" + region + '\'' +
                    ", district='" + district + '\'' +
                    ", population=" + population +
                    ", foundation='" + foundation + '\'' +
                    '}';
        }
    }

    public static void cityInRegion(List<City> city) {
        Comparator<City> districtSort = (a, b) -> a.region.compareTo(b.region);
        Comparator<City> districtAndNameSort = districtSort.thenComparing((a, b) -> a.name.compareTo(b.name));
        TreeSet<City> sortCity = new TreeSet<City>(districtAndNameSort);
        sortCity.addAll(city);
        City[] cityArray = sortCity.toArray(new City[0]);
        int count = 0;
        for (int i = 0; i < cityArray.length; i++) {
            count++;
            if (i == cityArray.length - 1) System.out.println(" - " + cityArray[i].region + " - " + count);
            else if (!cityArray[i].region.equals(cityArray[i + 1].region)) {
                System.out.println(" - " + cityArray[i].region + " - " + count);
                count = 0;
            }
        }
    }
    
    public static void main(String[] args) throws Exception {
        File data = new File("resources/CityData.csv");
        List<City> city = listCity(data);
        cityInRegion(city);
    }
}
